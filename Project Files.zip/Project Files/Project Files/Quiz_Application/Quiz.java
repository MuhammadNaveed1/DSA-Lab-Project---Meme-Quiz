package Quiz_Application;

import java.util.List;

public class Quiz {
    private List<Question> questions;    // List of questions
    private int currentQuestionIndex;    // Tracks which question user is on
    private int score;                   // Number of correct answers

    // Constructor
    public Quiz(List<Question> questions) {
        this.questions = questions;
        this.currentQuestionIndex = 0;
        this.score = 0;
    }

    public void insertionSortQuestions() {
        for (int i = 1; i < questions.size(); i++) {
            Question key = questions.get(i);
            int j = i - 1;

            while (j >= 0 &&
                    questions.get(j).getQuestionText().length() >
                            key.getQuestionText().length()) {

                questions.set(j + 1, questions.get(j));
                j--;
            }

            questions.set(j + 1, key);
        }
    }


    public int binarySearchQuestionByLength(int targetLength) {
        int left = 0;
        int right = questions.size() - 1;

        while (left <= right) {
            int mid = (left + right) / 2;
            int midLength = questions.get(mid).getQuestionText().length();

            if (midLength == targetLength) {
                return mid;
            } else if (midLength < targetLength) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return -1;
    }


    public Question getCurrentQuestion() {
        if (currentQuestionIndex < questions.size()) {
            return questions.get(currentQuestionIndex);
        }
        return null;
    }

    public boolean checkAnswer(int userAnswerIndex) {
        Question current = getCurrentQuestion();
        if (current != null && userAnswerIndex == current.getCorrectAnswerIndex()) {
            score++;
            return true;
        }
        return false;
    }

    public void nextQuestion() {
        currentQuestionIndex++;
    }

    public boolean isFinished() {
        return currentQuestionIndex >= questions.size();
    }

    public int getScore() {
        return score;
    }

    public int getTotalQuestions() {
        return questions.size();
    }

    public void reset() {
        currentQuestionIndex = 0;
        score = 0;
    }
}